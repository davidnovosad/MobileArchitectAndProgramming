package com.example.weighttrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class weightAppDatabase extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "WeightTracking.db";
    public static final int DATABASE_VERSION = 2;

    //here are the columns for the database
    public static final String TABLE_USERS = "usersTable";
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    public static final String COLUMN_FIRST_NAME = "firstName";
    public static final String COLUMN_TEXT_PERMISSION = "textPermission";
    public static final String COLUMN_PHONE_NUMBER = "phoneNumber";

    // Daily weight table columns
    public static final String TABLE_DAILY_WEIGHT = "dailyWeightTable";
    public static final String COLUMN_WEIGHT_ID = "weightId";
    public static final String COLUMN_WEIGHT_DATE = "weightDate";
    public static final String COLUMN_WEIGHT_VALUE = "weightValue";

    // Goal weight table columns
    public static final String TABLE_GOAL_WEIGHT = "goalWeightTable";
    public static final String COLUMN_GOAL_WEIGHT_ID = "goalId";
    public static final String COLUMN_GOAL_VALUE = "goalValue";

    //creating a table for users
    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_USERS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT, " +
                    COLUMN_PASSWORD + " TEXT, " +
                    COLUMN_FIRST_NAME + " TEXT, " +
                    COLUMN_TEXT_PERMISSION + " INTEGER, " +
                    COLUMN_PHONE_NUMBER + " TEXT);";

    private static final String TABLE_DAILY_WEIGHT_CREATE =
            "CREATE TABLE " + TABLE_DAILY_WEIGHT + " (" +
                    COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT, " +
                    COLUMN_WEIGHT_DATE + " TEXT, " +
                    COLUMN_WEIGHT_VALUE + " REAL);";

    private static final String TABLE_GOAL_WEIGHT_CREATE =
            "CREATE TABLE " + TABLE_GOAL_WEIGHT + " (" +
                    COLUMN_GOAL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT, " +
                    COLUMN_GOAL_VALUE + " REAL);";

    public weightAppDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
        db.execSQL(TABLE_DAILY_WEIGHT_CREATE); // Execute the SQL statement to create the daily weight table
        db.execSQL(TABLE_GOAL_WEIGHT_CREATE);  // Execute the SQL statement to create the goal weight table
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DAILY_WEIGHT);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL_WEIGHT);
        onCreate(db);
    }

    // Check the username and password against your database (replace with your actual validation logic)
    public boolean isLoginValid(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_ID};
        String selection = COLUMN_USERNAME + " = ?" + " AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        // Query the database to see if a matching user exists
        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);

        // Check if the cursor has at least one result
        boolean isValid = cursor.moveToFirst();

        // Close the cursor and database
        cursor.close();
        db.close();

        return isValid;
    }

    public boolean checkUserExists(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USERNAME,COLUMN_PASSWORD};

        String selection = "username = ? AND password = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);

        boolean userExists = cursor.moveToFirst();

        cursor.close();
        db.close();

        return userExists;
    }

    public void addUser(String username, String password, String firstN, float goalWeight, float weightNow, boolean textPermission, String currentDate,String phoneNumber) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues userValues = new ContentValues();
        userValues.put(COLUMN_PASSWORD,password);
        userValues.put(COLUMN_USERNAME,username);
        userValues.put(COLUMN_FIRST_NAME, firstN);
        userValues.put(COLUMN_TEXT_PERMISSION, textPermission ? 1 : 0);
        userValues.put(COLUMN_PHONE_NUMBER,phoneNumber);
        db.insert(TABLE_USERS, null, userValues);

        ContentValues dailyWeightValues = new ContentValues();
        dailyWeightValues.put(COLUMN_USERNAME, username);
        dailyWeightValues.put(COLUMN_WEIGHT_VALUE, weightNow);
        dailyWeightValues.put(COLUMN_WEIGHT_DATE, currentDate);
        db.insert(TABLE_DAILY_WEIGHT, null, dailyWeightValues);

        ContentValues goalWeightValues = new ContentValues();
        goalWeightValues.put(COLUMN_USERNAME, username);
        goalWeightValues.put(COLUMN_GOAL_VALUE, goalWeight);
        db.insert(TABLE_GOAL_WEIGHT, null, goalWeightValues);

        db.close();
    }

    public String fetchCurrentDateFromDatabase(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String date = "";

        String[] columns = {COLUMN_WEIGHT_DATE};
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};

        Cursor cursor = db.query(TABLE_DAILY_WEIGHT, columns, selection, selectionArgs, null, null, null);

        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(COLUMN_WEIGHT_DATE);
            if (columnIndex >= 0) {
                date = cursor.getString(columnIndex);
            }
        }

        cursor.close();
        db.close();

        return date;
    }

    public float fetchDailyWeightFromDatabase(String username, String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        float dailyWeight = 0.0f;

        String[] columns = {COLUMN_WEIGHT_VALUE};
        String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_WEIGHT_DATE + " = ?";
        String[] selectionArgs = {username, date};

        Cursor cursor = db.query(TABLE_DAILY_WEIGHT, columns, selection, selectionArgs, null, null, null);

        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(weightAppDatabase.COLUMN_WEIGHT_VALUE);
            if (columnIndex >= 0) {
                dailyWeight = cursor.getFloat(columnIndex);
            }
        }

        cursor.close();
        db.close();

        return dailyWeight;
    }

    public float getGoalWeight(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_GOAL_VALUE};
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};

        Cursor cursor = db.query(TABLE_GOAL_WEIGHT, columns, selection, selectionArgs, null, null, null);

        float goalWeight = 0.0f;

        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(COLUMN_GOAL_VALUE);
            if (columnIndex >= 0) {
                goalWeight = cursor.getFloat(columnIndex);
            }
        }

        cursor.close();
        db.close();

        return goalWeight;
    }

    // Method to fetch the user's first name from the database
    public String getFirstNameFromDatabase(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_FIRST_NAME};
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);

        String firstName = "";

        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(COLUMN_FIRST_NAME);
            if (columnIndex >= 0) {
                firstName = cursor.getString(columnIndex);
                Log.d("Database", "First name retrieved from the database: " + firstName);
            }
        } else {
            Log.d("Database", "No first name found for username: " + username);
        }

        cursor.close();
        db.close();

        return firstName;
    }

    public void addOrUpdateWeight(String username, String date, float weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();

        try {
            ContentValues values = new ContentValues();
            values.put(COLUMN_USERNAME, username);
            values.put(COLUMN_WEIGHT_DATE, date);
            values.put(COLUMN_WEIGHT_VALUE, weight);

            int updatedRows = db.update(TABLE_DAILY_WEIGHT, values,
                    COLUMN_USERNAME + " = ? AND " + COLUMN_WEIGHT_DATE + " = ?",
                    new String[]{username, date}
            );

            if (updatedRows == 0) {
                db.insert(TABLE_DAILY_WEIGHT, null, values);
            }

            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
    }

    public boolean isWeightEntryExists(String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        boolean entryExists = false;

        // Define the columns you want to retrieve
        String[] columns = {COLUMN_WEIGHT_DATE};

        // Define the selection criteria
        String selection = COLUMN_WEIGHT_DATE + " = ?";
        String[] selectionArgs = {date};

        // Query the database to check if a weight entry exists for the given date
        Cursor cursor = db.query(TABLE_DAILY_WEIGHT, columns, selection, selectionArgs, null, null, null);

        // Check if the cursor contains any rows (weight entry exists)
        if (cursor.getCount() > 0) {
            entryExists = true;
        }

        // Close the cursor and database
        cursor.close();
        db.close();

        return entryExists;
    }

    public boolean removeWeightEntry(String username, String date) {
        SQLiteDatabase db = this.getWritableDatabase();

        String whereClause = COLUMN_USERNAME + " = ? AND " + COLUMN_WEIGHT_DATE + " = ?";
        String[] whereArgs = {username, date};

        try {
            int rowsDeleted = db.delete(TABLE_DAILY_WEIGHT, whereClause, whereArgs);
            return rowsDeleted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            db.close();
        }
    }

    public String getUserPhoneNumber(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String phoneNumber = null;

        String[] columns = {COLUMN_PHONE_NUMBER};
        String selection = COLUMN_USERNAME + " = ?";
        String[] selectionArgs = {username};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);

        if (cursor.moveToFirst()) {
            int columnIndex = cursor.getColumnIndex(COLUMN_PHONE_NUMBER);
            if (columnIndex >= 0) {
                phoneNumber = cursor.getString(columnIndex);
            }
        }

        cursor.close();
        db.close();

        return phoneNumber;
    }
}

