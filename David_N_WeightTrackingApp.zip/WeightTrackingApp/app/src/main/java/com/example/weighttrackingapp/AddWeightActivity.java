package com.example.weighttrackingapp;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Toast;
import android.Manifest;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;

public class AddWeightActivity extends AppCompatActivity {
    private EditText addDailyWeight;
    private CalendarView calendarViewAddWeight;
    private Button buttonConfirm;
    private Button buttonPrevious;
    private String selectedDate;
    private weightAppDatabase dbHelper;
    private String username;
    private static final int PERMISSION_REQUEST_SEND_SMS = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_weight_layout);

        calendarViewAddWeight = findViewById(R.id.calendarViewAddWeight);
        addDailyWeight = findViewById(R.id.addDailyWeight);
        buttonConfirm = findViewById(R.id.buttonConfirmWeight);
        buttonPrevious = findViewById(R.id.buttonPrevious);
        dbHelper = new weightAppDatabase(this);
        selectedDate = null;
        username = getIntent().getStringExtra("username");
        String selectedDateFromIntent = getIntent().getStringExtra("selectedDate");

        if (selectedDateFromIntent != null) {
            selectedDate = selectedDateFromIntent;
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            try {
                Date date = sdf.parse(selectedDateFromIntent);
                calendarViewAddWeight.setDate(date.getTime());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        calendarViewAddWeight.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date date = new Date(year - 1900, month, dayOfMonth);
                selectedDate = sdf.format(date);
            }
        });

        buttonConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String weight = addDailyWeight.getText().toString();
                if (!weight.isEmpty() && selectedDate != null) {

                    dbHelper.addOrUpdateWeight(username, selectedDate, Float.parseFloat(weight));
                    Toast.makeText(AddWeightActivity.this, "Weight added successfully!", Toast.LENGTH_SHORT).show();

                    if (Float.parseFloat(weight) <= dbHelper.getGoalWeight(username)) {
                        checkSendSmsPermission();
                    }

                    finish();
                } else {
                    Toast.makeText(AddWeightActivity.this, "Please enter weight and/or select a date.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();

                Intent intent = new Intent(AddWeightActivity.this, MainScreenActivity.class);
                startActivity(intent);
            }
        });
    }

    private void checkSendSmsPermission() {
        if (checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            checkAndSendSms(Float.parseFloat(addDailyWeight.getText().toString()));
        } else {
            requestPermissions(new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_SEND_SMS);
        }
    }

    private void checkAndSendSms(float weight) {
        if (weight <= dbHelper.getGoalWeight(username)) {
            String phoneNumber = dbHelper.getUserPhoneNumber(username);
             SmsMessage.sendLongSMS(phoneNumber);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                checkAndSendSms(Float.parseFloat(addDailyWeight.getText().toString()));
            } else {
                Toast.makeText(this, "SEND_SMS permission is required to send SMS.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
