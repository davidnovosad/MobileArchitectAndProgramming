package com.example.weighttrackingapp;

import android.content.Intent;

import android.telephony.SmsManager;
import java.util.ArrayList;

public class SmsMessage {
    private static final int PERMISSION_REQUEST_SEND_SMS = 123;
    public static void sendLongSMS(String phoneNumber) {
        String message = "Congratulations! You've reached your goal.";
        SmsManager smsManager = SmsManager.getDefault();
        ArrayList<String> parts = smsManager.divideMessage(message);
        smsManager.sendMultipartTextMessage(phoneNumber, null, parts, null, null);
    }
}
