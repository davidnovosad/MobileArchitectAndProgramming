package com.example.weighttrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainScreenActivity extends AppCompatActivity {
    private TextView textDate;
    private TextView textDailyWeight;
    private TextView optimalWeightTextView;
    private TextView differenceWeightTextView;
    private ImageButton backButton;
    private ImageButton forwardButton;
    private Button removeWeightButton;
    private Button addWeightButton;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    private Date currentDate;
    private weightAppDatabase dbHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_screen_weight_display);

        String username = getIntent().getStringExtra("username");
        dbHelper = new weightAppDatabase(this);

        textDate = findViewById(R.id.textDate);
        textDailyWeight = findViewById(R.id.textDailyWeight);
        optimalWeightTextView = findViewById(R.id.textOptimalWeight);
        differenceWeightTextView = findViewById(R.id.textDifferenceWeight);
        backButton = findViewById(R.id.imageButtonBack);
        forwardButton = findViewById(R.id.imageButtonForward);
        removeWeightButton = findViewById(R.id.buttonRemoveWeight);
        addWeightButton = findViewById(R.id.buttonAddWeight);

        // set up today's date
        currentDate = new Date();
        textDate.setText(dateFormat.format(currentDate));

        // Update view with data
        updateViews();


        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                previousDay();
            }
        });

        forwardButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nextDay();
            }
        });

        removeWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainScreenActivity.this, RemoveWeightActivity.class);
                intent.putExtra("username", username);
                startActivity(intent);
            }
        });

        addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainScreenActivity.this, AddWeightActivity.class);
                intent.putExtra("username", username);
                String currentDate = dbHelper.fetchCurrentDateFromDatabase(username);
                intent.putExtra("selectedDate", currentDate);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateViews();
    }

    private void updateViews() {
        String username = getIntent().getStringExtra("username");

        String currentDate = dbHelper.fetchCurrentDateFromDatabase(username);
        float dailyWeight = dbHelper.fetchDailyWeightFromDatabase(username, currentDate);
        float goalWeight = dbHelper.getGoalWeight(username);
        float difference = dailyWeight - goalWeight;

        textDate.setText(currentDate);
        textDailyWeight.setText("Weight: " + dailyWeight + "lbs");
        optimalWeightTextView.setText("Optimal Weight: " + goalWeight + "lbs");
        differenceWeightTextView.setText("Difference: " + difference + "lbs");
    }

    private void previousDay() {
        String username = getIntent().getStringExtra("username");
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDate);
        calendar.add(Calendar.DAY_OF_YEAR, -1);
        currentDate = calendar.getTime();
        String formattedDate = dateFormat.format(currentDate);

        float dailyWeight = dbHelper.fetchDailyWeightFromDatabase(username, formattedDate);
        float goalWeight = dbHelper.getGoalWeight(username);
        float difference = dailyWeight - goalWeight;

        if (dailyWeight == 0.0){
            textDailyWeight.setText("Weight: N/A");
            Toast.makeText(MainScreenActivity.this, "No weight tracked! Add Weight with a button.", Toast.LENGTH_SHORT).show();
            differenceWeightTextView.setText("Difference: N/A");
        }
        else {
            textDailyWeight.setText("Weight: " + dailyWeight + "lbs");
            optimalWeightTextView.setText("Optimal Weight: " + goalWeight + "lbs");
            differenceWeightTextView.setText("Difference: " + difference + "lbs");
        }
        textDate.setText(dateFormat.format(currentDate));
    }

    private void nextDay() {
        String username = getIntent().getStringExtra("username");
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(currentDate);
        calendar.add(Calendar.DAY_OF_YEAR, 1);
        currentDate = calendar.getTime();
        String formattedDate = dateFormat.format(currentDate);

        float dailyWeight = dbHelper.fetchDailyWeightFromDatabase(username, formattedDate);
        float goalWeight = dbHelper.getGoalWeight(username);
        float difference = dailyWeight - goalWeight;

        if (dailyWeight == 0.0){
            textDailyWeight.setText("Weight: N/A");
            Toast.makeText(MainScreenActivity.this, "No weight tracked! Add Weight with a button.", Toast.LENGTH_SHORT).show();
            differenceWeightTextView.setText("Difference: N/A");
        }
        else {
            textDailyWeight.setText("Weight: " + dailyWeight + "lbs");
            optimalWeightTextView.setText("Optimal Weight: " + goalWeight + "lbs");
            differenceWeightTextView.setText("Difference: " + difference + "lbs");
        }
        textDate.setText(dateFormat.format(currentDate));
    }
}
