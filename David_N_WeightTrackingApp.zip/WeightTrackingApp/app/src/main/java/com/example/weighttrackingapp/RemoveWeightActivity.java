package com.example.weighttrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

public class RemoveWeightActivity extends AppCompatActivity {
    private CalendarView calendarViewRemoveWeight;
    private Button buttonConfirmWeightRemove;
    private Button buttonConfirmDeletion;
    private Button buttonPrevious;
    private TextView textConfirmDeleteLabel;
    private String selectedDate;
    private weightAppDatabase dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.remove_weight_layout);

        calendarViewRemoveWeight = findViewById(R.id.calendarViewRemoveWeight);
        buttonConfirmWeightRemove = findViewById(R.id.buttonConfirmWeightRemove);
        buttonConfirmDeletion = findViewById(R.id.buttonConfirmDeletion);
        textConfirmDeleteLabel = findViewById(R.id.textConfirmDeleteLabel);
        buttonPrevious = findViewById(R.id.buttonPrevious);
        dbHelper = new weightAppDatabase(this);
        selectedDate = null;

        buttonConfirmDeletion.setVisibility(View.GONE);
        textConfirmDeleteLabel.setVisibility(View.GONE);

        calendarViewRemoveWeight.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date date = new Date(year - 1900, month, dayOfMonth);
                selectedDate = sdf.format(date);
            }
        });

        buttonConfirmWeightRemove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (selectedDate != null) {
                    // Check if a weight entry exists for the selected date in the database
                    if (dbHelper.isWeightEntryExists(selectedDate)) {
                        // A weight entry exists, so hide the Confirm button
                        buttonConfirmWeightRemove.setVisibility(View.GONE);
                        textConfirmDeleteLabel.setVisibility(View.VISIBLE);
                        buttonConfirmDeletion.setVisibility(View.VISIBLE);
                    } else {
                        // No weight entry exists, show a message to the user
                        Toast.makeText(RemoveWeightActivity.this, "No weight entry found for the selected date.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    // Handle the case where no date is selected
                    Toast.makeText(RemoveWeightActivity.this, "Please select a date to remove.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonConfirmDeletion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = getIntent().getStringExtra("username");
                if (selectedDate != null) {
                    // Remove the selected date's entry from the database
                    boolean success = dbHelper.removeWeightEntry(username, selectedDate);
                    if (success) {
                        Toast.makeText(RemoveWeightActivity.this, "Weight entry removed successfully.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(RemoveWeightActivity.this, "Failed to remove weight entry.", Toast.LENGTH_SHORT).show();
                    }
                    finish();

                    Intent intent = new Intent(RemoveWeightActivity.this, MainScreenActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(RemoveWeightActivity.this, "Please select a date to remove.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();

                Intent intent = new Intent(RemoveWeightActivity.this, MainScreenActivity.class);
                startActivity(intent);
            }
        });
    }
}
