package com.example.weighttrackingapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;

import androidx.appcompat.app.AppCompatActivity;

public class AdditionalInfoActivity extends AppCompatActivity {
    private EditText firstNameEditText;
    private EditText goalWeightEditText;
    private EditText currentWeightEditText;
    private EditText phoneEditText;
    private TextView labelPhoneNumberView;
    private RadioGroup textPermissionRadioGroup;
    private Button signUpButton;
    private EditText textUsername;
    private EditText textPassword;
    private TextView previousLink;
    private weightAppDatabase dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.text_permission_layout);

        dbHelper = new weightAppDatabase(this);

        // Initialize UI components
        textUsername = findViewById(R.id.textUsername);
        textPassword = findViewById(R.id.textPassword);
        previousLink = findViewById(R.id.previous);
        firstNameEditText = findViewById(R.id.textFirstName);
        goalWeightEditText = findViewById(R.id.textGoalWeight);
        currentWeightEditText = findViewById(R.id.textCurrentWeight);
        textPermissionRadioGroup = findViewById(R.id.textPermissionOption);
        signUpButton = findViewById(R.id.buttonFinishSignup);
        phoneEditText = findViewById(R.id.editTextPhone);
        labelPhoneNumberView = findViewById(R.id.labelPhoneNumber);

        labelPhoneNumberView.setVisibility(View.GONE);
        phoneEditText.setVisibility(View.GONE);

        TextView previousLink = findViewById(R.id.previous);
        previousLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Finish the current RegistrationActivity
                finish();

                // Start the LoginActivity
                Intent intent = new Intent(AdditionalInfoActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        textPermissionRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radioButton3) {
                    labelPhoneNumberView.setVisibility(View.VISIBLE);
                    phoneEditText.setVisibility(View.VISIBLE);
                } else {
                    labelPhoneNumberView.setVisibility(View.GONE);
                    phoneEditText.setVisibility(View.GONE);
                }
            }
        });

        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Retrieve the input from user
                String username = textUsername.getText().toString();
                String password = textPassword.getText().toString();
                String firstName = firstNameEditText.getText().toString();

                if (username.isEmpty() || password.isEmpty() || firstName.isEmpty() || goalWeightEditText.getText().toString().isEmpty() || currentWeightEditText.getText().toString().isEmpty()) {
                    Toast.makeText(AdditionalInfoActivity.this, "Please fill in all required fields.", Toast.LENGTH_SHORT).show();
                    return;
                }

                float goalWeight = Float.parseFloat(goalWeightEditText.getText().toString());
                float currentWeight = Float.parseFloat(currentWeightEditText.getText().toString());

                int selectedRadioButtonId = textPermissionRadioGroup.getCheckedRadioButtonId();
                if (selectedRadioButtonId != -1) {
                    RadioButton selectedRadioButton = findViewById(selectedRadioButtonId);
                    boolean textPermission = selectedRadioButton.getText().toString().equals("Allow");

                    if (textPermission) {
                        // Check if "Allow" is selected
                        String phoneNumber = phoneEditText.getText().toString();

                        if (phoneNumber.isEmpty()) {
                            // If "Allow" is selected but no phone number is provided
                            Toast.makeText(AdditionalInfoActivity.this, "Please provide your phone number to proceed.", Toast.LENGTH_SHORT).show();
                            return; // Stop the registration process
                        }
                    }

                    // Check if the username and password already exist in your database
                    boolean userExists = dbHelper.checkUserExists(username, password);

                    if (userExists) {
                        // User exists, show message
                        signIn(username, password);
                    } else {
                        // Get the current date
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                        String currentDate = sdf.format(new Date());
                        String phoneNumber = phoneEditText.getText().toString();

                        // User doesn't exist, register them
                        dbHelper.addUser(username, password, firstName, goalWeight, currentWeight, textPermission, currentDate,phoneNumber);

                        // Move to the main screen
                        Intent intent = new Intent(AdditionalInfoActivity.this, MainScreenActivity.class);
                        intent.putExtra("username", username);
                        startActivity(intent);
                        finish();
                    }
                }
                else {
                    //inform user that they have to select one of the options
                    Toast.makeText(AdditionalInfoActivity.this, "Please select 'Allow' or 'Deny' to continue.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void signIn(String username, String password) {
        String message;

            message = "Account with username " + username + " already exists.";

            Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
        }

}
