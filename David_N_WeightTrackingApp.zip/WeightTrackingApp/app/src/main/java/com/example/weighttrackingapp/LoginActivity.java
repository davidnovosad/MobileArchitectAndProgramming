package com.example.weighttrackingapp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText usernameEditText;
    private EditText passwordEditText;
    private TextView registrationLink;
    private weightAppDatabase dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new weightAppDatabase(this);

        // Initialization of the views
        usernameEditText = findViewById(R.id.textUsername);
        passwordEditText = findViewById(R.id.textPassword);
        registrationLink = findViewById(R.id.labelNewUser);

        // when login button is clicked
        Button loginButton = findViewById(R.id.buttonLogin);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //get username and password
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                boolean isValid = dbHelper.isLoginValid(username, password);

                // Check the username and password in your database
                if (isValid) {
                    // if login correct app moves to the main screen
                    Intent intent = new Intent(LoginActivity.this, MainScreenActivity.class);
                    intent.putExtra("username", username);
                    Toast.makeText(LoginActivity.this, "Welcome, " + dbHelper.getFirstNameFromDatabase(username) + "!", Toast.LENGTH_SHORT).show();
                    startActivity(intent);
                    finish();
                } else {
                    // else credentials wrong error is shown
                    Toast.makeText(LoginActivity.this, "Username or password is incorrect", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Handle registration link click
        registrationLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate to the registration screen (SignUpActivity)
                Intent intent = new Intent(LoginActivity.this, AdditionalInfoActivity.class);
                startActivity(intent);
            }
        });
    }
}
