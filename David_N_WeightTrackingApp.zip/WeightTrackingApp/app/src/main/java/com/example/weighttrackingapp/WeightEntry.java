package com.example.weighttrackingapp;

public class WeightEntry {
    private String date;
    private float weight;

    public WeightEntry() {
        // Default constructor
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public float getWeight() {
        return weight;
    }

    public void setWeight(float weight) {
        this.weight = weight;
    }
}
